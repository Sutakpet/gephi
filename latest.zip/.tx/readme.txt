This folder contains the https://www.transifex.net/projects/p/gephi translation tool configuration to push and pull translation files from there.

!!Transifex needs "\" separators in windows to correctly find .po files, depending on your OS you should use / or \ in the config file. This can be easily replaced with a text editor.
See set_transifex.py script